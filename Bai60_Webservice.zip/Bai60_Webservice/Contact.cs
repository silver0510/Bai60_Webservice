﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Bai60_Webservice
{
    public class Contact
    {
        public int Ma { get; set; }
        public string Ten { get; set; }
        public string Phone { get; set; }
    }
}